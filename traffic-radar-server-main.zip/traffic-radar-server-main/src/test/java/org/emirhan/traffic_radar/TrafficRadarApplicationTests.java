package org.emirhan.traffic_radar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrafficRadarApplicationTests {

    @Test
    void contextLoads() {
    }

}
