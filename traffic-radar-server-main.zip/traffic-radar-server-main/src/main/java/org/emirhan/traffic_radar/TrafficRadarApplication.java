package org.emirhan.traffic_radar;

import org.emirhan.traffic_radar.data_structures.MyHashTable;
import org.emirhan.traffic_radar.model.Car;
import org.emirhan.traffic_radar.model.Cordinate;
import org.emirhan.traffic_radar.service.CarService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@SpringBootApplication
@EnableScheduling

public class TrafficRadarApplication {
    private final CarService carService;
    public TrafficRadarApplication(CarService carService) {
        this.carService = carService;
    }
    public static void main(String[] args) {
        SpringApplication.run(TrafficRadarApplication.class, args);
    }
    @GetMapping("/locations")
    public List<Cordinate> getCordinates() {
        return carService.getAllCoordinates();
    }
}
