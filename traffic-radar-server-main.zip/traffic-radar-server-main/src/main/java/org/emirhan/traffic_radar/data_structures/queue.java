package org.emirhan.traffic_radar.data_structures;

import java.util.LinkedList;
import java.util.Queue;

import org.emirhan.traffic_radar.model.Car;

public class queue {
    private Queue<Car> carQueue = new LinkedList<>();

    public void enqueue(Car car) {
        carQueue.offer(car);
    }

    public Car dequeue() {
        return carQueue.poll();
    }

    public boolean isEmpty() {
        return carQueue.isEmpty();
    }

    public int size() {
        return carQueue.size();
    }
}
