package org.emirhan.traffic_radar.data_structures;

import org.emirhan.traffic_radar.model.Car;

public class Node {
    public Car value;
    public Node next;
}
