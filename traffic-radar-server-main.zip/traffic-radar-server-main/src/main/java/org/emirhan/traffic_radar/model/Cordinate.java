package org.emirhan.traffic_radar.model;

public record Cordinate(Double lat,Double lng){}
