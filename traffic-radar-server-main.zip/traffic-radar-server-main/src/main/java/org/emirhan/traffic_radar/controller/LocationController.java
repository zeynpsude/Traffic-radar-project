

package org.emirhan.traffic_radar.controller;

import org.emirhan.traffic_radar.model.Cordinate;
import org.emirhan.traffic_radar.service.CarService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@CrossOrigin(origins = "http://localhost:5173")
@RestController
public class LocationController {

    private final CarService carService;

    public LocationController(CarService carService) {
        this.carService = carService;
    }

    @GetMapping("/locations")
    public List<Cordinate> getLocations() {
        return carService.getAllCoordinates();
    }
}
