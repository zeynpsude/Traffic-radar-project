package org.emirhan.traffic_radar.model;

public class Car {
    public String key;
    public Cordinate location;

    public Car(String key, Cordinate location) {
        this.key = key;
        this.location = location;
    }

    public String getKey() {
        return key;
    }

    public Cordinate getLocation() {
        return location;
    }

    public void setLocation(Cordinate location) {
        this.location = location;
    }
}
