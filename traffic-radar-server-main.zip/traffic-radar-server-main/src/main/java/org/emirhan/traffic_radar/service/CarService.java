package org.emirhan.traffic_radar.service;

import jakarta.annotation.PostConstruct;
import org.emirhan.traffic_radar.data_structures.MyHashTable;
import org.emirhan.traffic_radar.model.Car;
import org.emirhan.traffic_radar.model.Cordinate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.emirhan.traffic_radar.data_structures.queue;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class CarService {
    private final MyHashTable hTable = new MyHashTable();
    private final queue locationQueue = new queue();

    double minLat = 35.8086;
    double maxLat = 42.1076;
    double minLng = 25.6639;
    double maxLng = 44.7936;

    @PostConstruct
    public void init() {
        for (int i = 0; i < 10000; i++) {
            UUID uuid = UUID.randomUUID();
            double randomLat = getRandomInRange(minLat, maxLat);
            double randomLng = getRandomInRange(minLng, maxLng);
            Cordinate c = new Cordinate(randomLat, randomLng);
            Car car = new Car(uuid.toString(), c);
            hTable.put(car.key, car);
            locationQueue.enqueue(car);
        }
    }

    @Scheduled(fixedRate = 5000)
    public void updateLocation() {
        int size = locationQueue.size();
        for (int i = 0; i < size; i++) {
            Car car = locationQueue.dequeue();
            Cordinate newLoc = new Cordinate(getRandomInRange(minLat, maxLat), getRandomInRange(minLng, maxLng));
            car.setLocation(newLoc);
            hTable.put(car.key, car);
            locationQueue.enqueue(car);
            System.out.println("Güncellendi: " + car.key + " → " + newLoc);
        }
    }


    public List<Cordinate> getAllCoordinates() {
        List<Cordinate> locations = new ArrayList<>();
        for (Car car : hTable.getAllValues()) {
            locations.add(car.getLocation());
        }
        return locations;
    }

    private double getRandomInRange(double min, double max) {
        return min + Math.random() * (max - min);
    }
}