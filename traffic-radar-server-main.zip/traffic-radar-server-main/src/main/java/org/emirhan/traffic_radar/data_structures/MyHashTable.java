package org.emirhan.traffic_radar.data_structures;

import org.emirhan.traffic_radar.model.Car;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MyHashTable {
    private static final int SIZE = 1000;
    private List<Car>[] table;

    public MyHashTable() {
        table = new ArrayList[SIZE];
        for (int i = 0; i < SIZE; i++) {
            table[i] = new ArrayList<>();
        }
    }

    private int hash(String key) {
        return Math.abs(key.hashCode()) % SIZE;
    }

    public void put(String key, Car car) {
        int index = hash(key);
        for (int i = 0; i < table[index].size(); i++) {
            if (table[index].get(i).getKey().equals(key)) {
                table[index].set(i, car);
                return;
            }
        }
        table[index].add(car);
    }

    public Car get(String key) {
        int index = hash(key);
        for (Car car : table[index]) {
            if (car.getKey().equals(key)) {
                return car;
            }
        }
        return null;
    }

    public List<Car> getAllValues() {
        List<Car> allCars = new ArrayList<>();
        for (List<Car> bucket : table) {
            allCars.addAll(bucket);
        }
        return allCars;
    }
}